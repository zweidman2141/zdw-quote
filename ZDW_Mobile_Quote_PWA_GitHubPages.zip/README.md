# ZDW Mobile Quote — PWA

Progressive Web App for quick quotes (ZDW Mobile Auto Repair). Ready for GitHub Pages hosting.

## Quick Deploy (GitHub Pages)
1. Create a **new GitHub repo** (e.g., `zdw-quote`).
2. Upload **all files in this folder** to the repo **root** (keep file names the same).
3. Go to **Settings → Pages**:
   - **Source**: *Deploy from a branch*
   - **Branch**: `main` (or `master`), **Folder**: */ (root)*
4. Wait for Pages to go live, then open the site in **Safari on iPhone**, tap **Share → Add to Home Screen** to install.

## Optional: Custom Domain
- Edit the `CNAME` file to your domain (e.g., `quote.zdw-mobile.com`).
- In your DNS, add a CNAME record pointing to `<username>.github.io`.
- GitHub Pages will auto-configure HTTPS.

## iOS Install Notes
- iOS requires **HTTPS** for PWA install.
- After opening the site in **Safari**, use **Share → Add to Home Screen**.

## Files
- `index.html` — main app
- `manifest.webmanifest` — install metadata (icons, theme)
- `service-worker.js` — offline cache
- `icon-192.png`, `icon-512.png`, `apple-touch-icon.png` — app icons
- `.nojekyll` — ensures assets are served by GitHub Pages
- `CNAME` — optional, for your custom domain

## Version
Packaged on 2025-11-11T19:34:42Z.

